package com.example.midterm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
