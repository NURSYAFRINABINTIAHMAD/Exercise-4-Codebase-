package com.example.exercise4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
